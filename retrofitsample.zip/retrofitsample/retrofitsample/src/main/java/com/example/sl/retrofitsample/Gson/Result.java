package com.example.sl.retrofitsample.Gson;

/**
 * Created by sl on 2018/5/17.
 */

public class Result {

    /**
     * result : yes
     */

    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
